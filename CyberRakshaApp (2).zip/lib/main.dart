import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CyberRakshaApp());
}

// ============================================================
// REGION / HELPLINE DATA
// ============================================================

const String kPortalUrl = 'https://cybercrime.gov.in';

/// Opens a custom bottom sheet with direct options for Copy, WhatsApp, Twitter,
/// and system share (Instagram, Facebook, etc.).
Future<void> shareTextSheet(BuildContext context, String text,
    {String subject = 'Cyber Crime Complaint'}) async {
  showModalBottomSheet(
    context: context,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16.0)),
    ),
    builder: (BuildContext bc) {
      return SafeArea(
        child: Wrap(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text(
                'Share Complaint',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.copy, color: Colors.blue),
              title: const Text('Copy Text'),
              onTap: () async {
                Navigator.pop(bc);
                await Clipboard.setData(ClipboardData(text: text));
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Complaint text copied to clipboard!')),
                  );
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.chat, color: Colors.green),
              title: const Text('WhatsApp'),
              onTap: () async {
                Navigator.pop(bc);
                final uri = Uri.parse(
                    'https://wa.me/?text=${Uri.encodeComponent(text)}');
                try {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } catch (_) {
                  await Share.share(text);
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.alt_route, color: Colors.black87),
              title: const Text('Twitter / X'),
              onTap: () async {
                Navigator.pop(bc);
                final uri = Uri.parse(
                    'https://twitter.com/intent/tweet?text=${Uri.encodeComponent(text)}');
                try {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } catch (_) {
                  await Share.share(text);
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.purple),
              title: const Text('Instagram, Facebook & More (System Share)'),
              onTap: () async {
                Navigator.pop(bc);
                final box = context.findRenderObject() as RenderBox?;
                await Share.share(
                  text,
                  subject: subject,
                  sharePositionOrigin: box != null
                      ? box.localToGlobal(Offset.zero) & box.size
                      : null,
                );
              },
            ),
          ],
        ),
      );
    },
  );
}

class Helpline {
  final String label;
  final String number;
  final IconData icon;
  final Color color;
  const Helpline(this.label, this.number, this.icon, this.color);
}

const List<String> kRegions = [
  'Andhra Pradesh',
  'Arunachal Pradesh',
  'Assam',
  'Bihar',
  'Chhattisgarh',
  'Goa',
  'Gujarat',
  'Haryana',
  'Himachal Pradesh',
  'Jharkhand',
  'Karnataka',
  'Kerala',
  'Madhya Pradesh',
  'Maharashtra',
  'Manipur',
  'Meghalaya',
  'Mizoram',
  'Nagaland',
  'Odisha',
  'Punjab',
  'Rajasthan',
  'Sikkim',
  'Tamil Nadu',
  'Telangana',
  'Tripura',
  'Uttar Pradesh',
  'Uttarakhand',
  'West Bengal',
  'Andaman and Nicobar Islands',
  'Chandigarh',
  'Dadra and Nagar Haveli and Daman and Diu',
  'Delhi',
  'Jammu and Kashmir',
  'Ladakh',
  'Lakshadweep',
  'Puducherry',
];

const Map<String, List<Helpline>> kRegionExtras = {
  'Kerala': [
    Helpline('Kerala Pink Police', '1515', Icons.shield, Color(0xFFC2185B)),
  ],
  'Uttar Pradesh': [
    Helpline('UP Women Power Line', '1090', Icons.woman, Color(0xFFC2185B)),
  ],
  'Delhi': [
    Helpline('Delhi Women Helpline', '1091', Icons.woman, Color(0xFFC2185B)),
  ],
};

const List<Helpline> kNationalHelplines = [
  Helpline('Cyber Fraud (National)', '1930', Icons.phone, Color(0xFFB71C1C)),
  Helpline('Emergency (Police/Fire/Medical)', '112', Icons.local_police,
      Color(0xFF283593)),
  Helpline('Police', '100', Icons.local_police, Color(0xFF37474F)),
  Helpline('Women Helpline', '181', Icons.woman, Color(0xFF880E4F)),
  Helpline('Child Helpline', '1098', Icons.child_care, Color(0xFF00695C)),
];

List<Helpline> helplinesFor(String? region) {
  return [
    ...kNationalHelplines,
    if (region != null) ...(kRegionExtras[region] ?? const <Helpline>[]),
  ];
}

class ComplaintRecord {
  final String id;
  final String name;
  final String category;
  final String narrative;
  final String region;
  final String city;
  final List<String> fileNames;
  final String complaintText;
  final String status;
  final DateTime savedAt;

  const ComplaintRecord({
    required this.id,
    required this.name,
    required this.category,
    required this.narrative,
    required this.region,
    required this.city,
    required this.fileNames,
    required this.complaintText,
    required this.status,
    required this.savedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'category': category,
        'narrative': narrative,
        'region': region,
        'city': city,
        'fileNames': fileNames,
        'complaintText': complaintText,
        'status': status,
        'savedAt': savedAt.toIso8601String(),
      };

  factory ComplaintRecord.fromJson(Map<String, dynamic> j) => ComplaintRecord(
        id: j['id'] ?? '',
        name: j['name'] ?? '',
        category: j['category'] ?? '',
        narrative: j['narrative'] ?? '',
        region: j['region'] ?? '',
        city: j['city'] ?? '',
        fileNames: List<String>.from(j['fileNames'] ?? const []),
        complaintText: j['complaintText'] ?? '',
        status: j['status'] ?? 'draft',
        savedAt: DateTime.tryParse(j['savedAt'] ?? '') ?? DateTime.now(),
      );
}

class RecordStore {
  static const String _key = 'complaint_records';

  static Future<List<ComplaintRecord>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List;
      final records = list
          .map((e) => ComplaintRecord.fromJson(e as Map<String, dynamic>))
          .toList();
      records.sort((a, b) => b.savedAt.compareTo(a.savedAt));
      return records;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<ComplaintRecord> records) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _key, jsonEncode(records.map((r) => r.toJson()).toList()));
  }

  static Future<void> upsert(ComplaintRecord record) async {
    final records = await load();
    records.removeWhere((r) => r.id == record.id);
    records.add(record);
    await _write(records);
  }

  static Future<void> remove(String id) async {
    final records = await load();
    records.removeWhere((r) => r.id == id);
    await _write(records);
  }
}

class CyberRakshaApp extends StatelessWidget {
  const CyberRakshaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CyberRaksha',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E3A8A),
          brightness: Brightness.light,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E3A8A),
          foregroundColor: Colors.white,
          centerTitle: true,
          elevation: 2,
        ),
      ),
      home: const OnboardingApp(),
    );
  }
}

class OnboardingApp extends StatefulWidget {
  const OnboardingApp({super.key});

  @override
  State<OnboardingApp> createState() => _OnboardingAppState();
}

class _OnboardingAppState extends State<OnboardingApp>
    with WidgetsBindingObserver {
  static const String _defaultCategory = 'Financial Fraud / UPI Scam';
  static const String _autoSaveKey = 'autosave_form';

  final PageController _pageController = PageController();
  int _currentPage = 0;

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _complaintController = TextEditingController();
  final TextEditingController _urlController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();

  String _selectedCategory = _defaultCategory;
  final List<String> _categories = [
    'Financial Fraud / UPI Scam',
    'Phishing / Fraudulent Web Link',
    'Deepfake / Image Morphing',
    'Identity Theft / Account Hacking',
    'Cyberstalking / Harassment',
    'Other Cyber Crime'
  ];

  String? _selectedRegion;

  late stt.SpeechToText _speech;
  bool _isListening = false;

  List<PlatformFile> _attachedFiles = [];

  String _urlAnalysisResult = '';
  Color _urlResultColor = Colors.black87;

  String _generatedComplaint = '';

  String? _editingId;

  Timer? _autoSaveTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _speech = stt.SpeechToText();
    _restoreState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _autoSaveTimer?.cancel();
    _pageController.dispose();
    _nameController.dispose();
    _complaintController.dispose();
    _urlController.dispose();
    _cityController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive) {
      _autoSaveNow();
    }
  }

  Future<void> _restoreState() async {
    final prefs = await SharedPreferences.getInstance();
    final region = prefs.getString('region_state');
    final city = prefs.getString('region_city') ?? '';
    final auto = prefs.getString(_autoSaveKey);

    String name = '', narrative = '', category = _defaultCategory;
    String? editingId;
    if (auto != null) {
      try {
        final m = jsonDecode(auto) as Map<String, dynamic>;
        name = m['name'] ?? '';
        narrative = m['narrative'] ?? '';
        category = m['category'] ?? _defaultCategory;
        editingId = m['editingId'];
      } catch (_) {}
    }

    if (!mounted) return;
    setState(() {
      _selectedRegion = kRegions.contains(region) ? region : null;
      _cityController.text = city;
      _nameController.text = name;
      _complaintController.text = narrative;
      _selectedCategory =
          _categories.contains(category) ? category : _defaultCategory;
      _editingId = editingId;
    });

    _nameController.addListener(_scheduleAutoSave);
    _complaintController.addListener(_scheduleAutoSave);
  }

  void _scheduleAutoSave() {
    _autoSaveTimer?.cancel();
    _autoSaveTimer = Timer(const Duration(milliseconds: 1500), _autoSaveNow);
  }

  Future<void> _autoSaveNow() async {
    _autoSaveTimer?.cancel();
    final prefs = await SharedPreferences.getInstance();
    if (!_hasContent) {
      await prefs.remove(_autoSaveKey);
      return;
    }
    await prefs.setString(
      _autoSaveKey,
      jsonEncode({
        'name': _nameController.text,
        'narrative': _complaintController.text,
        'category': _selectedCategory,
        'editingId': _editingId,
      }),
    );
  }

  Future<void> _saveRegion() async {
    final prefs = await SharedPreferences.getInstance();
    if (_selectedRegion != null) {
      await prefs.setString('region_state', _selectedRegion!);
    }
    await prefs.setString('region_city', _cityController.text.trim());
  }

  bool get _hasContent =>
      _nameController.text.trim().isNotEmpty ||
      _complaintController.text.trim().isNotEmpty ||
      _attachedFiles.isNotEmpty;

  void _resetForm() {
    _autoSaveTimer?.cancel();
    if (_isListening) {
      _speech.stop();
    }
    setState(() {
      _nameController.clear();
      _complaintController.clear();
      _urlController.clear();
      _selectedCategory = _defaultCategory;
      _attachedFiles = [];
      _generatedComplaint = '';
      _urlAnalysisResult = '';
      _urlResultColor = Colors.black87;
      _isListening = false;
      _editingId = null;
      _currentPage = 0;
    });
    if (_pageController.hasClients) {
      _pageController.jumpToPage(0);
    }
  }

  Future<void> _saveRecord({required String status}) async {
    final complaint =
        _generatedComplaint.isEmpty ? _buildComplaint() : _generatedComplaint;
    final record = ComplaintRecord(
      id: _editingId ?? DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameController.text.trim(),
      category: _selectedCategory,
      narrative: _complaintController.text.trim(),
      region: _selectedRegion ?? '',
      city: _cityController.text.trim(),
      fileNames: _attachedFiles.map((f) => f.name).toList(),
      complaintText: complaint,
      status: status,
      savedAt: DateTime.now(),
    );
    await RecordStore.upsert(record);
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_autoSaveKey);
  }

  Future<void> _saveDraftAndReset({bool showMessage = true}) async {
    if (!_hasContent) {
      _resetForm();
      return;
    }
    await _saveRecord(status: 'draft');
    if (!mounted) return;
    _resetForm();
    if (showMessage) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Draft saved. Form cleared.')),
      );
    }
  }

  Future<void> _openHistory() async {
    final resumed = await Navigator.of(context).push<ComplaintRecord>(
      MaterialPageRoute(builder: (_) => const HistoryPage()),
    );
    if (resumed != null && mounted) {
      _resumeDraft(resumed);
    }
  }

  void _resumeDraft(ComplaintRecord r) {
    setState(() {
      _nameController.text = r.name;
      _complaintController.text = r.narrative;
      _selectedCategory =
          _categories.contains(r.category) ? r.category : _defaultCategory;
      _generatedComplaint = r.complaintText;
      _attachedFiles = [];
      _editingId = r.id;
    });
    if (_pageController.hasClients) {
      _pageController.jumpToPage(3);
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(r.fileNames.isEmpty
              ? 'Draft loaded.'
              : 'Draft loaded. Re-attach evidence files (${r.fileNames.length} were attached).')),
    );
  }

  void _listenVoice() async {
    try {
      if (!_isListening) {
        bool available = await _speech.initialize(
          onStatus: (val) {
            if (val == 'done' || val == 'notListening') {
              if (mounted) setState(() => _isListening = false);
            }
          },
          onError: (val) {
            if (mounted) setState(() => _isListening = false);
          },
        );
        if (available) {
          if (mounted) setState(() => _isListening = true);
          _speech.listen(
            onResult: (val) {
              if (mounted) {
                setState(() {
                  _complaintController.text = val.recognizedWords;
                });
              }
            },
          );
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                  content: Text(
                      "Microphone access unavailable on this browser preview.")),
            );
          }
        }
      } else {
        if (mounted) setState(() => _isListening = false);
        _speech.stop();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isListening = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Speech recognition error: $e")),
        );
      }
    }
  }

  Future<void> _pickFiles() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ['jpg', 'png', 'pdf'],
      );

      if (result != null && mounted) {
        setState(() {
          _attachedFiles = result.files;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("File picker error: $e")),
        );
      }
    }
  }

  String _buildComplaint() {
    String date = DateFormat('dd-MM-yyyy').format(DateTime.now());
    String filesSummary = _attachedFiles.isEmpty
        ? 'No external files attached.'
        : '${_attachedFiles.length} file(s) attached: ${_attachedFiles.map((f) => f.name).join(', ')}';

    final city = _cityController.text.trim();
    final place = [
      if (city.isNotEmpty) city,
      if (_selectedRegion != null) _selectedRegion!,
    ].join(', ');
    final cellLine = place.isEmpty
        ? 'The Cyber Crime Cell, Government Cyber Authority'
        : 'The Cyber Crime Cell, $place';

    return """TO,
$cellLine
Date: $date

SUBJECT: Formal Complaint Regarding $_selectedCategory

Respected Officer,

I am submitting a formal report regarding a cyber crime incident involving "$_selectedCategory".

1. COMPLAINANT DETAILS:
   - Name: ${_nameController.text.isEmpty ? 'Anonymous / Citizen' : _nameController.text}${place.isEmpty ? '' : '\n   - Location: $place'}

2. INCIDENT CATEGORY:
   - Incident Type: $_selectedCategory

3. INCIDENT STATEMENT & DETAILS:
   ${_complaintController.text.isEmpty ? 'Detailed statement pending.' : _complaintController.text}

4. EVIDENCE PRESERVED:
   - $filesSummary

I request the Cyber Crime Investigation Cell to take formal note of this incident, initiate necessary action under applicable laws, and trace the perpetrator.

Sincerely,
${_nameController.text.isEmpty ? 'Citizen' : _nameController.text}""";
  }

  void _generateDraft() {
    setState(() {
      _generatedComplaint = _buildComplaint();
    });
  }

  Future<void> _downloadPDF() async {
    if (_generatedComplaint.isEmpty) _generateDraft();

    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Padding(
            padding: const pw.EdgeInsets.all(24),
            child: pw.Text(
              _generatedComplaint,
              style: const pw.TextStyle(fontSize: 12, lineSpacing: 4),
            ),
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  Future<bool> _openPortal() async {
    final uri = Uri.parse(kPortalUrl);
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        return true;
      }
    } catch (_) {}
    try {
      if (await launchUrl(uri, mode: LaunchMode.platformDefault)) {
        return true;
      }
    } catch (_) {}
    return false;
  }

  Future<void> _sendToPortal() async {
    final hasContent = _hasContent;
    if (hasContent && _generatedComplaint.isEmpty) _generateDraft();
    final text = _buildComplaint();

    final opened = await _openPortal();

    if (!mounted) return;
    if (!opened) {
      try {
        await Clipboard.setData(const ClipboardData(text: kPortalUrl));
      } catch (_) {}
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text(
                'Could not open the browser. Link copied: cybercrime.gov.in')),
      );
      return;
    }

    if (!hasContent) return;
    try {
      await Clipboard.setData(ClipboardData(text: text));
    } catch (_) {}
    if (!mounted) return;

    final submitted = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Complaint copied'),
        content: const Text(
            'Your complaint text is copied. On cybercrime.gov.in choose "Report Cyber Crime", '
            'then paste it into the incident details and submit.\n\n'
            'Did you submit the complaint on the portal?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Not yet'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Yes, submitted'),
          ),
        ],
      ),
    );

    if (!mounted) return;
    if (submitted == true) {
      await _saveRecord(status: 'sent');
      if (!mounted) return;
      _resetForm();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Marked as sent. Form cleared.')),
      );
    }
  }

  void _analyzeURL(String inputUrl) {
    if (inputUrl.trim().isEmpty) {
      setState(() {
        _urlAnalysisResult = "Please enter a valid URL to check.";
        _urlResultColor = Colors.orange.shade800;
      });
      return;
    }

    String lower = inputUrl.toLowerCase().trim();
    List<String> warnings = [];

    if (!lower.startsWith("https://")) {
      warnings.add("⚠️ Unencrypted Connection (Not HTTPS).");
    }
    if (RegExp(r'(\d{1,3}\.){3}\d{1,3}').hasMatch(lower)) {
      warnings.add("🚨 IP Address URL (High Risk Phishing Pattern).");
    }
    if (lower.contains("login") ||
        lower.contains("verify") ||
        lower.contains("bank") ||
        lower.contains("kyc") ||
        lower.contains("update")) {
      warnings.add("⚠️ Suspicious credential harvesting keywords detected.");
    }

    setState(() {
      if (warnings.isEmpty) {
        _urlAnalysisResult =
            "✅ Standard URL Structure detected. Always verify domain before logging in.";
        _urlResultColor = Colors.green.shade800;
      } else {
        _urlAnalysisResult = warnings.join("\n");
        _urlResultColor = Colors.red.shade800;
      }
    });
  }

  Future<void> _makeCall(String number) async {
    final Uri url = Uri.parse('tel:$number');
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Could not launch dialer for $number")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CyberRaksha Portal'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: 'Drafts & Sent',
            onPressed: _openHistory,
          ),
          IconButton(
            icon: const Icon(Icons.save_outlined),
            tooltip: 'Save Draft',
            onPressed: () => _saveDraftAndReset(),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(5, (index) {
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.symmetric(horizontal: 4.0),
                    height: 8.0,
                    width: _currentPage == index ? 24.0 : 8.0,
                    decoration: BoxDecoration(
                      color: _currentPage == index
                          ? const Color(0xFF1E3A8A)
                          : Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(4.0),
                    ),
                  );
                }),
              ),
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                onPageChanged: (int page) {
                  setState(() {
                    _currentPage = page;
                  });
                  _autoSaveNow();
                },
                children: [
                  _buildSlide1Category(),
                  _buildSlide2Statement(),
                  _buildSlide3Evidence(),
                  _buildSlide4DraftPDF(),
                  _buildSlide5UrlAndChecklist(),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(12.0),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                border: Border(top: BorderSide(color: Colors.grey.shade300)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (_currentPage > 0)
                    OutlinedButton(
                      onPressed: () {
                        _pageController.previousPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                        );
                      },
                      child: const Text('Previous'),
                    )
                  else
                    const SizedBox.shrink(),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1E3A8A),
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () {
                      if (_currentPage < 4) {
                        _pageController.nextPage(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeInOut,
                        );
                      } else {
                        _saveDraftAndReset();
                      }
                    },
                    child: Text(_currentPage == 4 ? 'Finish' : 'Next'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSlide1Category() {
    final helplines = helplinesFor(_selectedRegion);
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Step 1: Location & Incident Category',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Choose your state / UT so the right helplines are shown, then select the type of cyber crime.',
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _selectedRegion,
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'State / Union Territory',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.location_on),
            ),
            items: kRegions
                .map((r) => DropdownMenuItem<String>(
                      value: r,
                      child: Text(r, overflow: TextOverflow.ellipsis),
                    ))
                .toList(),
            onChanged: (String? v) {
              setState(() => _selectedRegion = v);
              _saveRegion();
            },
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _cityController,
            onChanged: (_) => _saveRegion(),
            decoration: const InputDecoration(
              labelText: 'City / District',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.location_city),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'Complainant Full Name (optional)',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _selectedCategory,
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Select Cyber Incident Type',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.report_problem),
            ),
            items: _categories.map((String category) {
              return DropdownMenuItem<String>(
                value: category,
                child: Text(
                  category,
                  overflow: TextOverflow.ellipsis,
                ),
              );
            }).toList(),
            onChanged: (String? newValue) {
              if (newValue != null) {
                setState(() {
                  _selectedCategory = newValue;
                });
                _scheduleAutoSave();
              }
            },
          ),
          const SizedBox(height: 28),
          Text(
            _selectedRegion == null
                ? 'Emergency Helplines (India)'
                : 'Emergency Helplines for $_selectedRegion',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          ...helplines.map(
            (h) => Card(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                dense: true,
                leading: Icon(h.icon, color: h.color),
                title: Text(h.label),
                subtitle: Text(h.number),
                trailing: IconButton(
                  icon: Icon(Icons.call, color: h.color),
                  tooltip: 'Call ${h.number}',
                  onPressed: () => _makeCall(h.number),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSlide2Statement() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Step 2: Incident Narrative',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Describe the sequence of events clearly. You can use typed text or the speech microphone.',
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _complaintController,
            maxLines: 8,
            decoration: const InputDecoration(
              hintText:
                  'Describe what happened (e.g. Transaction IDs, fraudulent phone numbers, social media handles)...',
              border: OutlineInputBorder(),
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    _isListening ? Colors.red : const Color(0xFF1E3A8A),
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              icon: Icon(_isListening ? Icons.mic_off : Icons.mic),
              label:
                  Text(_isListening ? 'Stop Listening' : 'Hold / Tap to Speak'),
              onPressed: _listenVoice,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSlide3Evidence() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Step 3: Evidence Locker',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Attach screenshots, chat transaction exports, or altered image files from local storage.',
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 20),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
            ),
            icon: const Icon(Icons.attach_file),
            label: const Text('Pick Evidence Screenshots / Files'),
            onPressed: _pickFiles,
          ),
          const SizedBox(height: 20),
          _attachedFiles.isEmpty
              ? const Card(
                  child: Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Text('No evidence files selected yet.'),
                  ),
                )
              : ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _attachedFiles.length,
                  itemBuilder: (context, index) {
                    final file = _attachedFiles[index];
                    return Card(
                      child: ListTile(
                        leading: const Icon(Icons.insert_drive_file,
                            color: Color(0xFF1E3A8A)),
                        title: Text(file.name),
                        subtitle:
                            Text('${(file.size / 1024).toStringAsFixed(1)} KB'),
                      ),
                    );
                  },
                ),
        ],
      ),
    );
  }

  Widget _buildSlide4DraftPDF() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Step 4: Draft Legal Complaint',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1E3A8A),
              foregroundColor: Colors.white,
              minimumSize: const Size.fromHeight(45),
            ),
            icon: const Icon(Icons.description),
            label: const Text('Generate Formal Complaint'),
            onPressed: _generateDraft,
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.grey.shade400),
            ),
            child: Text(
              _generatedComplaint.isEmpty
                  ? 'Click "Generate Formal Complaint" above to review document.'
                  : _generatedComplaint,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade700,
                    foregroundColor: Colors.white,
                  ),
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('Download PDF'),
                  onPressed: _downloadPDF,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.share),
                  label: const Text('Share Text'),
                  onPressed: () {
                    if (_generatedComplaint.isNotEmpty) {
                      shareTextSheet(context, _generatedComplaint);
                    }
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Card(
            color: Colors.indigo.shade50,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.account_balance, color: Color(0xFF1E3A8A)),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Submit to National Cyber Crime Portal',
                          style: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Copies your complaint and opens cybercrime.gov.in. Paste it into the incident details on the portal and submit.',
                    style: TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1E3A8A),
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(45),
                    ),
                    icon: const Icon(Icons.send),
                    label: const Text('Send to cybercrime.gov.in'),
                    onPressed: _sendToPortal,
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(45),
                    ),
                    icon: const Icon(Icons.drafts_outlined),
                    label: const Text('Save as Draft & Clear'),
                    onPressed: () => _saveDraftAndReset(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSlide5UrlAndChecklist() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Step 5: Link Analyzer & Emergency Checklist',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _urlController,
            decoration: InputDecoration(
              labelText: 'Paste Suspicious Link / URL',
              hintText: 'http://192.168.0.1/verify-bank',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.search),
                onPressed: () => _analyzeURL(_urlController.text),
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_urlAnalysisResult.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _urlResultColor.withValues(alpha: 0.1),
                border: Border.all(color: _urlResultColor),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _urlAnalysisResult,
                style: TextStyle(
                    color: _urlResultColor, fontWeight: FontWeight.bold),
              ),
            ),
          const SizedBox(height: 24),
          const Text(
            'Golden Hour Emergency Checklist:',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(12.0),
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(Icons.check_box, color: Colors.green),
                    title: Text('1. Call 1930 to freeze bank debit pipelines.'),
                  ),
                  ListTile(
                    leading: Icon(Icons.check_box, color: Colors.green),
                    title: Text(
                        '2. Take full-screen screenshots of payment reference IDs.'),
                  ),
                  ListTile(
                    leading: Icon(Icons.check_box, color: Colors.green),
                    title:
                        Text('3. Report and block the scammer phone/profile.'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  List<ComplaintRecord> _records = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final r = await RecordStore.load();
    if (!mounted) return;
    setState(() {
      _records = r;
      _loading = false;
    });
  }

  Future<void> _delete(ComplaintRecord r) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete this complaint?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) {
      await RecordStore.remove(r.id);
      _reload();
    }
  }

  void _viewSent(ComplaintRecord r) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(r.category),
        content: SingleChildScrollView(
          child: SelectableText(
            r.complaintText,
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: r.complaintText));
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Copied to clipboard')),
              );
            },
            child: const Text('Copy'),
          ),
          TextButton(
            onPressed: () => shareTextSheet(context, r.complaintText),
            child: const Text('Share'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildList(String status) {
    final items = _records.where((r) => r.status == status).toList();
    if (items.isEmpty) {
      return Center(
        child: Text(
          status == 'draft' ? 'No drafts yet.' : 'Nothing sent yet.',
          style: const TextStyle(color: Colors.grey),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: items.length,
      itemBuilder: (context, i) {
        final r = items[i];
        final place = [
          if (r.city.isNotEmpty) r.city,
          if (r.region.isNotEmpty) r.region,
        ].join(', ');
        final preview = r.narrative.isEmpty ? 'No statement yet' : r.narrative;
        return Card(
          child: ListTile(
            leading: Icon(
              status == 'draft' ? Icons.edit_note : Icons.check_circle,
              color: status == 'draft' ? Colors.orange.shade800 : Colors.green,
            ),
            title: Text(r.category),
            subtitle: Text(
              '${DateFormat('dd MMM yyyy, HH:mm').format(r.savedAt)}${place.isEmpty ? '' : '\n$place'}\n$preview',
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
            ),
            isThreeLine: true,
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () => _delete(r),
            ),
            onTap: () {
              if (status == 'draft') {
                Navigator.pop(context, r);
              } else {
                _viewSent(r);
              }
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final drafts = _records.where((r) => r.status == 'draft').length;
    final sent = _records.where((r) => r.status == 'sent').length;
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('My Complaints'),
          bottom: TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [
              Tab(icon: const Icon(Icons.edit_note), text: 'Drafts ($drafts)'),
              Tab(icon: const Icon(Icons.send), text: 'Sent ($sent)'),
            ],
          ),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                children: [
                  _buildList('draft'),
                  _buildList('sent'),
                ],
              ),
      ),
    );
  }
}
